import { FilePond } from "components/shared/form/Filepond";

const Filled = () => {
  return (
    <div className="max-w-xl">
      <FilePond filled allowMultiple />
    </div>
  );
};

export { Filled };
