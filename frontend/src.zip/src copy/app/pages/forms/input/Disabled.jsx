import { Input } from "components/ui";

const Disabled = () => {
  return (
    <div className="max-w-xl">
      <Input placeholder="Enter Username" disabled />
    </div>
  );
};

export { Disabled };
