import { Input } from "components/ui";

const Default = () => {
  return (
    <div className="max-w-xl">
      <Input placeholder="Enter Username" />
    </div>
  );
};

export { Default };
