import { Switch } from "components/ui";

const Default = () => {
  return <Switch defaultChecked />;
};

export { Default };
