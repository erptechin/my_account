import { Textarea } from "components/ui";

const Default = () => {
  return (
    <div className="max-w-xl">
      <Textarea placeholder="Enter text" rows="5" />
    </div>
  );
};

export { Default };
