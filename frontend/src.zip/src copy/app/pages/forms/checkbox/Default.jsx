import { Checkbox } from "components/ui";

const Default = () => {
  return <Checkbox defaultChecked />;
};

export { Default };
