import { Radio } from "components/ui";

const Default = () => {
  return <Radio defaultChecked />;
};

export { Default };
