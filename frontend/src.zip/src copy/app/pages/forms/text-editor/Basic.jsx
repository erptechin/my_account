import { TextEditor } from "components/shared/form/TextEditor";

const Basic = () => {
  return (
    <div className="max-w-xl">
      <TextEditor placeholder="Enter your content here..." />
    </div>
  );
};

export { Basic };
